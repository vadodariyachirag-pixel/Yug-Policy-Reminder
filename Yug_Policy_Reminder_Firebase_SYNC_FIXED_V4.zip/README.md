# Yug Policy Reminder

Firebase/Firestore sync build. Both devices must sign in with the same Email/Password Firebase account. Policies are stored locally in Room for offline use and synchronized to Firestore in real time. Existing local policies are uploaded on first sync.
