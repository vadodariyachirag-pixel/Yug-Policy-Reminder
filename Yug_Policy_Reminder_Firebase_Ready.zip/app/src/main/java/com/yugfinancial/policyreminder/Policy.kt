package com.yugfinancial.policyreminder
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "policies")
data class Policy(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleNumber: String,
    val vehicleName: String,
    val vehicleType: String,
    val customerName: String,
    val phone: String,
    val expiryDate: Long
)
