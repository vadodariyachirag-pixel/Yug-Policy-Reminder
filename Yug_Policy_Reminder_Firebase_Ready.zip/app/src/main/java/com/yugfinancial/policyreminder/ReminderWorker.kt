package com.yugfinancial.policyreminder

import android.app.*
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.room.Room
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import java.text.SimpleDateFormat
import java.util.*

class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val db = Room.databaseBuilder(applicationContext, AppDatabase::class.java, "policy.db").build()
        val today = Calendar.getInstance().zero()
        db.policyDao().getAll().forEach { p ->
            val expiry = Calendar.getInstance().apply { timeInMillis = p.expiryDate }.zero()
            val days = ((expiry.timeInMillis - today.timeInMillis) / 86400000L).toInt()
            if (days == 20 || days == 10) notify(p, days)
        }
        return Result.success()
    }

    private fun Calendar.zero(): Calendar {
        set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0)
        return this
    }

    private fun notify(p: Policy, days: Int) {
        val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = "policy_expiry"
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            NotificationChannel(channel, "Policy Expiry", NotificationManager.IMPORTANCE_HIGH)
        )
        val date = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date(p.expiryDate))
        val n = NotificationCompat.Builder(applicationContext, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Policy Expiry Reminder")
            .setContentText("${p.customerName} • ${p.vehicleNumber}: $days days remaining")
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "Customer: ${p.customerName}\nVehicle: ${p.vehicleNumber}\nExpiry: $date\n$days days remaining."
            ))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).build()
        nm.notify((p.id * 100 + days).toInt(), n)
    }
}
