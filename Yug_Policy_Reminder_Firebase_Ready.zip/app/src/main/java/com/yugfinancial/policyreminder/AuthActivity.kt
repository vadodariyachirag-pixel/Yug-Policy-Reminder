package com.yugfinancial.policyreminder

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import com.google.firebase.auth.FirebaseAuth

class AuthActivity : ComponentActivity() {
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        auth = FirebaseAuth.getInstance()
        if (auth.currentUser != null) {
            openMain()
            return
        }
        setContentView(R.layout.activity_auth)

        val email = findViewById<EditText>(R.id.email)
        val password = findViewById<EditText>(R.id.password)
        val login = findViewById<Button>(R.id.btnLogin)
        val create = findViewById<Button>(R.id.btnCreate)
        val status = findViewById<TextView>(R.id.status)

        fun valid(): Boolean {
            if (email.text.toString().trim().isEmpty() || password.text.length < 6) {
                status.text = "Email and password (minimum 6 characters) required."
                return false
            }
            return true
        }

        login.setOnClickListener {
            if (!valid()) return@setOnClickListener
            setBusy(true)
            auth.signInWithEmailAndPassword(email.text.toString().trim(), password.text.toString())
                .addOnCompleteListener(this) { task ->
                    setBusy(false)
                    if (task.isSuccessful) openMain()
                    else status.text = "Login failed: ${task.exception?.localizedMessage ?: "Please check details."}"
                }
        }

        create.setOnClickListener {
            if (!valid()) return@setOnClickListener
            setBusy(true)
            auth.createUserWithEmailAndPassword(email.text.toString().trim(), password.text.toString())
                .addOnCompleteListener(this) { task ->
                    setBusy(false)
                    if (task.isSuccessful) openMain()
                    else status.text = "Account creation failed: ${task.exception?.localizedMessage ?: "Please try again."}"
                }
        }
    }

    private fun setBusy(busy: Boolean) {
        findViewById<Button>(R.id.btnLogin)?.isEnabled = !busy
        findViewById<Button>(R.id.btnCreate)?.isEnabled = !busy
    }

    private fun openMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
