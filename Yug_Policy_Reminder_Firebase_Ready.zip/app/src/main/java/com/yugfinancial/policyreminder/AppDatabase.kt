package com.yugfinancial.policyreminder
import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Policy::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun policyDao(): PolicyDao
}
