# Yug Policy Reminder – Version 2

Professional insurance policy expiry tracker for Yug Financial Services.

### Included
- Manual policy entry
- Gadi number, model, type
- Customer name + mobile number
- Expiry date
- Automatic 20-day and 10-day notifications
- All / 20 Days / 10 Days / Expired filters
- Customer and vehicle-number search
- Edit / Delete
- Direct phone call
- WhatsApp renewal message
- CSV backup
- CSV restore
- Yug Financial Services branding
- No PIN / password

### Android Studio
Open this project folder in Android Studio and Sync Gradle.
Then Run on your Android phone.

### Reminder
Android notification permission must be allowed. Some phones may also require background/battery optimization to be disabled for this app for the most reliable reminders.

## Firebase sync – Version 2.4
- Firebase Email/Password login and account creation
- Cloud Firestore sync under `users/{uid}/policies`
- Existing Room records are uploaded after first login
- Records created/edited on another device are pulled into the local database
- App remains usable offline using Room

### Required before building
Put the Firebase Android configuration file downloaded for this app at:
`app/google-services.json`

The Android package name must be `com.yugfinancial.policyreminder`.

### Firestore rules
Use the rules in `firebase/firestore.rules` so each signed-in user can access only their own policy collection.
