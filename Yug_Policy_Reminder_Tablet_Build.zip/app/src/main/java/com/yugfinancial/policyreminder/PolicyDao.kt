package com.yugfinancial.policyreminder
import androidx.room.*

@Dao
interface PolicyDao {
    @Query("SELECT * FROM policies ORDER BY expiryDate ASC")
    suspend fun getAll(): List<Policy>
    @Insert suspend fun insert(policy: Policy): Long
    @Update suspend fun update(policy: Policy)
    @Delete suspend fun delete(policy: Policy)
}
