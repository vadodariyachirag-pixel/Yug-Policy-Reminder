package com.yugfinancial.policyreminder

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import androidx.work.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private lateinit var db: AppDatabase
    private lateinit var adapter: PolicyAdapter
    private var all = listOf<Policy>()
    private var mode = "all"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        db = Room.databaseBuilder(this, AppDatabase::class.java, "policy.db").build()

        adapter = PolicyAdapter(emptyList(), ::showEditDialog) { p ->
            AlertDialog.Builder(this).setTitle("Delete Policy?")
                .setMessage("${p.customerName} - ${p.vehicleNumber}")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete") { _, _ -> Thread { db.policyDao().delete(p); runOnUiThread { load() } }.start() }
                .show()
        }

        findViewById<RecyclerView>(R.id.recycler).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        findViewById<Button>(R.id.btnAdd).setOnClickListener { showAddDialog(null) }
        findViewById<Button>(R.id.btnAll).setOnClickListener { mode="all"; refresh() }
        findViewById<Button>(R.id.btn20).setOnClickListener { mode="20"; refresh() }
        findViewById<Button>(R.id.btn10).setOnClickListener { mode="10"; refresh() }
        findViewById<Button>(R.id.btnExpired).setOnClickListener { mode="expired"; refresh() }

        findViewById<EditText>(R.id.search).addTextChangedListenerSimple { refresh() }

        findViewById<Button>(R.id.btnBackup).setOnClickListener { backupCsv() }
        findViewById<Button>(R.id.btnRestore).setOnClickListener { restoreCsv() }

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf("android.permission.POST_NOTIFICATIONS"), 100)

        schedule()
        load()
    }

    private fun schedule() {
        val req = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "policy_daily_reminder", ExistingPeriodicWorkPolicy.UPDATE, req
        )
    }

    private fun load() {
        Thread {
            all = db.policyDao().getAll()
            runOnUiThread { refresh() }
        }.start()
    }

    private fun refresh() {
        val q = findViewById<EditText>(R.id.search).text.toString().trim().lowercase()
        val today = Calendar.getInstance().zero().timeInMillis
        val filtered = all.filter { p ->
            val match = q.isBlank() || p.customerName.lowercase().contains(q) || p.vehicleNumber.lowercase().contains(q)
            val days = ((Calendar.getInstance().apply { timeInMillis=p.expiryDate }.zero().timeInMillis - today) / 86400000L).toInt()
            val status = when(mode) {
                "20" -> days == 20
                "10" -> days == 10
                "expired" -> days < 0
                else -> true
            }
            match && status
        }
        adapter.update(filtered)
        findViewById<TextView>(R.id.summary).text = "Total: ${all.size}   |   Showing: ${filtered.size}"
    }

    private fun showEditDialog(p: Policy) = showAddDialog(p)

    private fun showAddDialog(edit: Policy?) {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(35,5,35,5) }
        fun f(h: String, value: String="") = EditText(this).apply { hint=h; setSingleLine(true); setText(value); box.addView(this) }

        val number=f("Gadi Number", edit?.vehicleNumber ?: "")
        val name=f("Gadi Name / Model", edit?.vehicleName ?: "")
        val type=f("Gadi Type (Car / Bike / Other)", edit?.vehicleType ?: "")
        val customer=f("Customer Name", edit?.customerName ?: "")
        val phone=f("Customer Mobile Number", edit?.phone ?: "")
        val dateBtn=Button(this)
        var selected=Calendar.getInstance().apply { if(edit!=null) timeInMillis=edit.expiryDate }
        dateBtn.text="Expiry: ${fmt(selected.timeInMillis)}"; box.addView(dateBtn)
        dateBtn.setOnClickListener {
            DatePickerDialog(this,{_,y,m,d->
                selected=Calendar.getInstance().apply { set(y,m,d,0,0,0); set(Calendar.MILLISECOND,0) }
                dateBtn.text="Expiry: ${fmt(selected.timeInMillis)}"
            },selected.get(Calendar.YEAR),selected.get(Calendar.MONTH),selected.get(Calendar.DAY_OF_MONTH)).show()
        }

        AlertDialog.Builder(this).setTitle(if(edit==null) "Add Policy" else "Edit Policy").setView(box)
            .setNegativeButton("Cancel",null)
            .setPositiveButton("Save") { _,_ ->
                if(number.text.isBlank() || customer.text.isBlank()) {
                    Toast.makeText(this,"Gadi Number and Customer Name required",Toast.LENGTH_LONG).show(); return@setPositiveButton
                }
                val p=Policy(edit?.id ?: 0, number.text.toString().trim().uppercase(), name.text.toString().trim(),
                    type.text.toString().trim(), customer.text.toString().trim(), phone.text.toString().trim(),
                    selected.timeInMillis)
                Thread { if(edit==null) db.policyDao().insert(p) else db.policyDao().update(p); runOnUiThread { load() } }.start()
            }.show()
    }

    private fun backupCsv() {
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type="text/csv"; putExtra(Intent.EXTRA_TITLE,"Yug_Policy_Backup.csv")
        }
        startActivityForResult(i, 200)
    }

    private fun restoreCsv() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type="text/*"; addCategory(Intent.CATEGORY_OPENABLE) }
        startActivityForResult(i, 201)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK || data?.data==null) return
        val uri=data.data!!
        if(requestCode==200) Thread {
            val sb=StringBuilder("id,vehicleNumber,vehicleName,vehicleType,customerName,phone,expiryDate\n")
            all.forEach { p -> sb.append("${p.id},\"${p.vehicleNumber}\",\"${p.vehicleName}\",\"${p.vehicleType}\",\"${p.customerName}\",\"${p.phone}\",${p.expiryDate}\n") }
            contentResolver.openOutputStream(uri)?.use { it.write(sb.toString().toByteArray()) }
            runOnUiThread { Toast.makeText(this,"CSV backup saved",Toast.LENGTH_LONG).show() }
        }.start()
        else if(requestCode==201) Thread {
            val text=contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
            val lines=text.lines().drop(1).filter{it.isNotBlank()}
            lines.forEach { line ->
                val c=Regex("""(?:^|,)("(?:[^"]|"")*"|[^,]*)""").findAll(line).map{it.groupValues[1].trim('"').replace("\"\"","\"")}.toList()
                if(c.size>=7) db.policyDao().insert(Policy(
                    vehicleNumber=c[1],vehicleName=c[2],vehicleType=c[3],customerName=c[4],phone=c[5],expiryDate=c[6].toLongOrNull()?:0
                ))
            }
            runOnUiThread { load(); Toast.makeText(this,"CSV restore completed",Toast.LENGTH_LONG).show() }
        }.start()
    }

    private fun fmt(ms:Long)=SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(Date(ms))
    private fun Calendar.zero():Calendar { set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);return this }
}

private fun EditText.addTextChangedListenerSimple(fn:()->Unit) {
    addTextChangedListener(object: android.text.TextWatcher {
        override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
        override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){fn()}
        override fun afterTextChanged(s:android.text.Editable?){}
    })
}
