package com.yugfinancial.policyreminder

import android.content.Intent
import android.net.Uri
import android.view.*
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.*

class PolicyAdapter(
    private var items: List<Policy>,
    private val onEdit: (Policy) -> Unit,
    private val onDelete: (Policy) -> Unit
) : RecyclerView.Adapter<PolicyAdapter.VH>() {

    private val df = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
    fun update(newItems: List<Policy>) { items = newItems; notifyDataSetChanged() }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_policy, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val p = items[position]
        h.name.text = p.customerName
        h.details.text = "${p.vehicleNumber} • ${p.vehicleName} • ${p.vehicleType}"
        h.expiry.text = "Expiry: ${df.format(Date(p.expiryDate))}"

        h.call.setOnClickListener {
            if (p.phone.isNotBlank()) {
                parentContext(h).startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${p.phone}")))
            } else Toast.makeText(parentContext(h), "Phone number not added", Toast.LENGTH_SHORT).show()
        }
        h.whatsapp.setOnClickListener {
            if (p.phone.isBlank()) {
                Toast.makeText(parentContext(h), "Phone number not added", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val msg = "Namaste ${p.customerName}, tamari ${p.vehicleNumber} policy ni expiry date ${df.format(Date(p.expiryDate))} che.\n\nBest discount sathe tamari policy renewal karava mate YUG FINANCIAL SERVICES no sampark karo.\n\nThank You 🙏\nYUG FINANCIAL SERVICES"
            val url = "https://wa.me/${p.phone.replace(Regex("[^0-9]"), "")}?text=${Uri.encode(msg)}"
            parentContext(h).startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
        h.edit.setOnClickListener { onEdit(p) }
        h.delete.setOnClickListener { onDelete(p) }
    }

    private fun parentContext(h: VH) = h.itemView.context
    override fun getItemCount() = items.size

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.name)
        val details: TextView = v.findViewById(R.id.details)
        val expiry: TextView = v.findViewById(R.id.expiry)
        val call: Button = v.findViewById(R.id.call)
        val whatsapp: Button = v.findViewById(R.id.whatsapp)
        val edit: Button = v.findViewById(R.id.edit)
        val delete: Button = v.findViewById(R.id.delete)
    }
}
