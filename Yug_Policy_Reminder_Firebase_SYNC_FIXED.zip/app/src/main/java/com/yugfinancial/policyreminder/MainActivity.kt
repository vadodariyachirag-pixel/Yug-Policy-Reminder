package com.yugfinancial.policyreminder

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private lateinit var db: AppDatabase
    private lateinit var adapter: PolicyAdapter
    private var all = emptyList<Policy>()
    private var mode = "all"
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val firestore by lazy { FirebaseFirestore.getInstance() }
    private var cloudListener: com.google.firebase.firestore.ListenerRegistration? = null

    private val backupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) backupCsvTo(uri)
    }

    private val restoreLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) restoreCsvFrom(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = Room.databaseBuilder(this, AppDatabase::class.java, "policy.db").build()

        adapter = PolicyAdapter(
            emptyList(),
            onEdit = ::showEditDialog,
            onDelete = { policy -> confirmDelete(policy) }
        )

        findViewById<RecyclerView>(R.id.recycler).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        val addClick = { showAddDialog(null) }
        findViewById<Button>(R.id.btnAdd).setOnClickListener { addClick() }
        findViewById<Button>(R.id.btnAddTop).setOnClickListener { addClick() }
        findViewById<Button>(R.id.btnAll).setOnClickListener { mode = "all"; refresh() }
        findViewById<Button>(R.id.btn20).setOnClickListener { mode = "11_20"; refresh() }
        findViewById<Button>(R.id.btn10).setOnClickListener { mode = "0_10"; refresh() }
        findViewById<Button>(R.id.btnExpired).setOnClickListener { mode = "expired"; refresh() }
        findViewById<EditText>(R.id.search).addTextChangedListenerSimple { refresh() }
        val backupClick = { backupLauncher.launch("Yug_Policy_Backup.csv") }
        val restoreClick = { restoreLauncher.launch(arrayOf("text/*", "text/csv")) }
        findViewById<Button>(R.id.btnBackup).setOnClickListener { backupClick() }
        findViewById<Button>(R.id.btnRestore).setOnClickListener { restoreClick() }
        findViewById<Button>(R.id.btnBackupTop).setOnClickListener { backupClick() }
        findViewById<Button>(R.id.btnRestoreTop).setOnClickListener { restoreClick() }

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, "android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf("android.permission.POST_NOTIFICATIONS"), 100)
        }

        schedule()
        load()
    }

    private fun schedule() {
        val request = PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "policy_daily_reminder",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    private fun load() {
        lifecycleScope.launch {
            all = withContext(Dispatchers.IO) { db.policyDao().getAll() }
            refresh()
            attachCloudSync()
        }
    }

    private fun attachCloudSync() {
        val uid = auth.currentUser?.uid ?: return
        cloudListener?.remove()
        val ref = firestore.collection("users").document(uid).collection("policies")

        cloudListener = ref.addSnapshotListener { snapshot, error ->
            if (error != null || snapshot == null) return@addSnapshotListener
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    val cloudNumbers = snapshot.documents.mapNotNull { it.getString("vehicleNumber") }.toSet()

                    // Cloud is the shared source of truth for records that already exist there.
                    for (doc in snapshot.documents) {
                        val number = doc.getString("vehicleNumber") ?: continue
                        val expiry = doc.getLong("expiryDate") ?: continue
                        val localPolicy = db.policyDao().getByVehicleNumber(number)
                        val cloudPolicy = Policy(
                            id = localPolicy?.id ?: 0,
                            vehicleNumber = number,
                            vehicleName = doc.getString("vehicleName") ?: "",
                            vehicleType = doc.getString("vehicleType") ?: "",
                            customerName = doc.getString("customerName") ?: "",
                            phone = doc.getString("phone") ?: "",
                            expiryDate = expiry
                        )
                        if (localPolicy == null) db.policyDao().insert(cloudPolicy)
                        else db.policyDao().update(cloudPolicy)
                    }

                    // On first sync, upload local-only records so existing policies are migrated.
                    val local = db.policyDao().getAll()
                    local.filter { it.vehicleNumber !in cloudNumbers }.forEach { syncPolicyToCloud(it) }

                    withContext(Dispatchers.Main) {
                        all = db.policyDao().getAll()
                        refresh()
                    }
                } catch (_: Exception) {
                    // Keep using Room if the network is temporarily unavailable.
                }
            }
        }
    }

    private fun syncPolicyToCloud(policy: Policy) {
        val uid = auth.currentUser?.uid ?: return
        val data = hashMapOf(
            "vehicleNumber" to policy.vehicleNumber,
            "vehicleName" to policy.vehicleName,
            "vehicleType" to policy.vehicleType,
            "customerName" to policy.customerName,
            "phone" to policy.phone,
            "expiryDate" to policy.expiryDate
        )
        Tasks.await(
            firestore.collection("users").document(uid)
                .collection("policies").document(policy.vehicleNumber).set(data)
        )
    }

    private fun deleteFromCloud(vehicleNumber: String) {
        val uid = auth.currentUser?.uid ?: return
        Tasks.await(
            firestore.collection("users").document(uid)
                .collection("policies").document(vehicleNumber).delete()
        )
    }

    private fun confirmDelete(policy: Policy) {
        AlertDialog.Builder(this)
            .setTitle("Delete Policy?")
            .setMessage("${policy.customerName} - ${policy.vehicleNumber}")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        db.policyDao().delete(policy)
                        deleteFromCloud(policy.vehicleNumber)
                    }
                    load()
                }
            }
            .show()
    }

    private fun refresh() {
        val q = findViewById<EditText>(R.id.search).text.toString().trim().lowercase(Locale.getDefault())
        val today = Calendar.getInstance().zero().timeInMillis

        val filtered = all.filter { policy ->
            val match = q.isBlank() ||
                policy.customerName.lowercase(Locale.getDefault()).contains(q) ||
                policy.vehicleNumber.lowercase(Locale.getDefault()).contains(q)

            val expiry = Calendar.getInstance().apply { timeInMillis = policy.expiryDate }.zero().timeInMillis
            val days = ((expiry - today) / DAY_MS).toInt()

            val status = when (mode) {
                "0_10" -> days in 0..10
                "11_20" -> days in 11..20
                "expired" -> days < 0
                else -> true
            }
            match && status
        }

        adapter.update(filtered)
        findViewById<TextView>(R.id.summary).text = "Total: ${all.size}   |   Showing: ${filtered.size}"
        findViewById<TextView>(R.id.emptyMessage).visibility =
            if (filtered.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun showEditDialog(policy: Policy) = showAddDialog(policy)

    private fun showAddDialog(edit: Policy?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(35, 5, 35, 5)
        }

        fun field(hint: String, value: String = "") = EditText(this).apply {
            this.hint = hint
            setSingleLine(true)
            setText(value)
            box.addView(this)
        }

        val number = field("Gadi Number", edit?.vehicleNumber ?: "")
        val name = field("Gadi Name / Model", edit?.vehicleName ?: "")
        val type = field("Gadi Type (Car / Bike / Other)", edit?.vehicleType ?: "")
        val customer = field("Customer Name", edit?.customerName ?: "")
        val phone = field("Customer Mobile Number", edit?.phone ?: "")

        val dateButton = Button(this)
        var selected = Calendar.getInstance().apply {
            if (edit != null) timeInMillis = edit.expiryDate
            zero()
        }
        dateButton.text = "Expiry: ${fmt(selected.timeInMillis)}"
        box.addView(dateButton)

        dateButton.setOnClickListener {
            DatePickerDialog(
                this,
                { _, year, month, day ->
                    selected = Calendar.getInstance().apply {
                        set(year, month, day, 0, 0, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    dateButton.text = "Expiry: ${fmt(selected.timeInMillis)}"
                },
                selected.get(Calendar.YEAR),
                selected.get(Calendar.MONTH),
                selected.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        AlertDialog.Builder(this)
            .setTitle(if (edit == null) "Add Policy" else "Edit Policy")
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                if (number.text.isBlank() || customer.text.isBlank()) {
                    Toast.makeText(this, "Gadi Number and Customer Name required", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }

                val policy = Policy(
                    id = edit?.id ?: 0,
                    vehicleNumber = number.text.toString().trim().uppercase(Locale.getDefault()),
                    vehicleName = name.text.toString().trim(),
                    vehicleType = type.text.toString().trim(),
                    customerName = customer.text.toString().trim(),
                    phone = phone.text.toString().trim(),
                    expiryDate = selected.timeInMillis
                )

                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        if (edit == null) {
                            db.policyDao().insert(policy)
                        } else {
                            if (edit.vehicleNumber != policy.vehicleNumber) {
                                deleteFromCloud(edit.vehicleNumber)
                            }
                            db.policyDao().update(policy)
                        }
                        syncPolicyToCloud(policy)
                    }
                    load()
                }
            }
            .show()
    }

    private fun backupCsvTo(uri: android.net.Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            val csv = buildString {
                appendLine("id,vehicleNumber,vehicleName,vehicleType,customerName,phone,expiryDate")
                all.forEach { policy ->
                    appendLine(
                        listOf(
                            policy.id,
                            csvField(policy.vehicleNumber),
                            csvField(policy.vehicleName),
                            csvField(policy.vehicleType),
                            csvField(policy.customerName),
                            csvField(policy.phone),
                            policy.expiryDate
                        ).joinToString(",")
                    )
                }
            }
            contentResolver.openOutputStream(uri)?.use { it.write(csv.toByteArray(Charsets.UTF_8)) }
            withContext(Dispatchers.Main) {
                Toast.makeText(this@MainActivity, "CSV backup saved", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun restoreCsvFrom(uri: android.net.Uri) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
                val lines = text.lines().drop(1).filter { it.isNotBlank() }
                var imported = 0

                for (line in lines) {
                    val c = parseCsvLine(line)
                    if (c.size >= 7) {
                        db.policyDao().insert(
                            Policy(
                                vehicleNumber = c[1],
                                vehicleName = c[2],
                                vehicleType = c[3],
                                customerName = c[4],
                                phone = c[5],
                                expiryDate = c[6].toLongOrNull() ?: continue
                            )
                        )
                        imported++
                    }
                }

                withContext(Dispatchers.Main) {
                    load()
                    Toast.makeText(this@MainActivity, "CSV restore completed: $imported records", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@MainActivity, "CSV restore failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun csvField(value: String): String = "\"${value.replace("\"", "\"\"")}\""

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var quoted = false
        var i = 0
        while (i < line.length) {
            val ch = line[i]
            when {
                ch == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> {
                    current.append('"')
                    i++
                }
                ch == '"' -> quoted = !quoted
                ch == ',' && !quoted -> {
                    result.add(current.toString())
                    current.clear()
                }
                else -> current.append(ch)
            }
            i++
        }
        result.add(current.toString())
        return result
    }

    private fun fmt(ms: Long): String = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date(ms))

    private fun Calendar.zero(): Calendar {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
        return this
    }

    override fun onDestroy() {
        cloudListener?.remove()
        cloudListener = null
        super.onDestroy()
    }

    companion object {
        private const val DAY_MS = 86_400_000L
    }
}

private fun EditText.addTextChangedListenerSimple(fn: () -> Unit) {
    addTextChangedListener(object : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = fn()
        override fun afterTextChanged(s: android.text.Editable?) = Unit
    })
}
